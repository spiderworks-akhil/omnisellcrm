import React from 'react';

const ApiNoResults = () => {
    return (
        <div>
            
        </div>
    );
};

export default ApiNoResults;
