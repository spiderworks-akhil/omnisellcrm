import React from 'react';

export const LeadMeeting = () => {
    return (
        <div>

        </div>
    );
};
