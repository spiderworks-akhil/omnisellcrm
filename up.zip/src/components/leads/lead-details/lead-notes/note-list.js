import React from 'react';

const NoteList = () => {
    return (
        <div>

        </div>
    );
};

export default NoteList;
