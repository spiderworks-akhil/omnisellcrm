import React from 'react';

export const LeadQuotation = () => {
    return (
        <div>

        </div>
    );
};
