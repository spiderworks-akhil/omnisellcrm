import React from 'react';

export const LeadPayments = () => {
    return (
        <div>

        </div>
    );
};
