import React from 'react';

const LeadAddNotes = () => {
    return (
        <div>
            
        </div>
    );
};

export default LeadAddNotes;
