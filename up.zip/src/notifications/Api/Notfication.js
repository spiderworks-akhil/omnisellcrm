import React from 'react';

const Notfication = (props) => {
    return (
        <div></div>
    );
}

export default Notfication;